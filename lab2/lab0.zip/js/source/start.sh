#!/bin/bash
node .